import Foundation
import SpriteKit

public class GameScene: SKScene {
    
    var blueBall: SKSpriteNode!
    var blueHexagon: SKSpriteNode!
    var blueSquare: SKSpriteNode!
    var greenBall: SKSpriteNode!
    var greenHexagon: SKSpriteNode!
    var greenSquare: SKSpriteNode!
    var redBall: SKSpriteNode!
    var redHexagon: SKSpriteNode!
    var redSquare: SKSpriteNode!
    
    var selectedBall: SKSpriteNode?
    
    override public func didMove(to view: SKView) {
        // Get label node from scene and store it for use later
        
        blueBall = self.childNode(withName: "blueBall") as! SKSpriteNode
        blueHexagon = self.childNode(withName: "blueHexagon") as! SKSpriteNode
        blueSquare = self.childNode(withName: "blueSquare") as! SKSpriteNode
        greenBall = self.childNode(withName: "greenBall") as! SKSpriteNode
        greenHexagon = self.childNode(withName: "greenHexagon") as! SKSpriteNode
        greenSquare = self.childNode(withName: "greenSquare") as! SKSpriteNode
        redBall = self.childNode(withName: "redBall") as! SKSpriteNode
        redHexagon = self.childNode(withName: "redHexagon") as! SKSpriteNode
        redSquare = self.childNode(withName: "redSquare") as! SKSpriteNode
        
    }
    
    @objc static override public var supportsSecureCoding: Bool {
        // SKNode conforms to NSSecureCoding, so any subclass going
        // through the decoding process must support secure coding
        get {
            return true
        }
    }
    
    func touchDown(atPoint pos : CGPoint) {
        if blueBall.contains(pos){
            selectedBall = blueBall
        }
        if blueHexagon.contains(pos){
            selectedBall = blueHexagon
        }
        if blueSquare.contains(pos){
            selectedBall = blueSquare
        }
        if greenBall.contains(pos) {
            selectedBall = greenBall
        }
        if greenHexagon.contains(pos) {
            selectedBall = greenHexagon
        }
        if greenSquare.contains(pos) {
            selectedBall = greenSquare
        }
        if redBall.contains(pos) {
            selectedBall = redBall
        }
        if redHexagon.contains(pos) {
            selectedBall = redHexagon
        }
        if redSquare.contains(pos) {
            selectedBall = redSquare
        }
        
    }
    
    func touchMoved(toPoint pos : CGPoint) {
        if selectedBall != nil{
            selectedBall?.position = pos
        }
    }
    
    func touchUp(atPoint pos : CGPoint) {
        selectedBall = nil
    }
    
    override public func mouseDown(with event: NSEvent) {
        touchDown(atPoint: event.location(in: self))
    }
    
    override public func mouseDragged(with event: NSEvent) {
        touchMoved(toPoint: event.location(in: self))
    }
    
    override public func mouseUp(with event: NSEvent) {
        touchUp(atPoint: event.location(in: self))
    }
    
    override public func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    }
}
